import React, { useRef, useState, useEffect } from 'react';
import { EditorState, CanvasObject, AssetItem } from '../types';
import { DraggableObject } from './DraggableObject';
import { DPI, BLEED_INCHES } from '../constants';
import { generateId, screenToCanvasCoordinates } from '../utils';

interface EditorCanvasProps {
  state: EditorState;
  isPanningMode: boolean;
  onUpdateObject: (id: string, updates: Partial<CanvasObject>) => void;
  onSelectObject: (id: string | null) => void;
  onAddObject: (obj: CanvasObject) => void;
  onDeleteObject: (id: string) => void;
  onChangeOrder: (id: string, dir: 'up' | 'down') => void;
  onUpdatePanOffset: (offset: { x: number, y: number }) => void;
}

export const EditorCanvas: React.FC<EditorCanvasProps> = ({
  state,
  isPanningMode,
  onUpdateObject,
  onSelectObject,
  onAddObject,
  onDeleteObject,
  onChangeOrder,
  onUpdatePanOffset
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { currentSpreadIndex, spreads, albumSize, scale, panOffset, showGrid, showBleed } = state;
  const currentSpread = spreads[currentSpreadIndex];

  // Logic Dimensions (Full 300 DPI resolution)
  const pageWidthPx = albumSize.widthInches * DPI;
  const pageHeightPx = albumSize.heightInches * DPI;
  const spreadWidthPx = pageWidthPx * 2;
  const spreadHeightPx = pageHeightPx;
  
  // Bleed calculations
  const bleedPx = BLEED_INCHES * DPI;

  // --- PANNING LOGIC ---
  const isDraggingPan = useRef(false);
  const lastPanPos = useRef({ x: 0, y: 0 });

  const handlePanMouseDown = (e: React.MouseEvent) => {
    if (!isPanningMode) return;
    isDraggingPan.current = true;
    lastPanPos.current = { x: e.clientX, y: e.clientY };
  };

  useEffect(() => {
    const handleGlobalMouseMove = (e: MouseEvent) => {
      if (!isDraggingPan.current) return;
      
      const dx = e.clientX - lastPanPos.current.x;
      const dy = e.clientY - lastPanPos.current.y;
      
      onUpdatePanOffset({
        x: panOffset.x + dx,
        y: panOffset.y + dy
      });
      
      lastPanPos.current = { x: e.clientX, y: e.clientY };
    };

    const handleGlobalMouseUp = () => {
      isDraggingPan.current = false;
    };

    if (isPanningMode) {
      window.addEventListener('mousemove', handleGlobalMouseMove);
      window.addEventListener('mouseup', handleGlobalMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleGlobalMouseMove);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, [isPanningMode, panOffset, onUpdatePanOffset]);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const assetData = e.dataTransfer.getData('application/json');
    if (!assetData) return;

    const asset: AssetItem = JSON.parse(assetData);
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;

    const coords = screenToCanvasCoordinates(e.clientX, e.clientY, rect, scale);
    
    // Default size: 40% of page width
    const defaultWidth = pageWidthPx * 0.4;
    const ratio = asset.width / asset.height;
    const defaultHeight = defaultWidth / ratio;
    
    const newObject: CanvasObject = {
      id: generateId(),
      type: 'image',
      src: asset.url,
      x: coords.x - defaultWidth / 2,
      y: coords.y - defaultHeight / 2,
      width: defaultWidth,
      height: defaultHeight,
      rotation: 0,
      // Initialize content dims
      contentX: 0,
      contentY: 0,
      contentWidth: defaultWidth,
      contentHeight: defaultHeight,
      zIndex: currentSpread.objects.length + 1,
      opacity: 1,
    };

    onAddObject(newObject);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleBackgroundClick = () => {
    if (!isPanningMode) {
      onSelectObject(null);
    }
  };

  return (
    <div 
      className={`flex-1 bg-gray-200 overflow-hidden flex items-center justify-center relative select-none ${isPanningMode ? (isDraggingPan.current ? 'cursor-grabbing' : 'cursor-grab') : ''}`}
      onClick={handleBackgroundClick}
      onMouseDown={handlePanMouseDown}
    >
      <div 
        ref={containerRef}
        className="relative shrink-0 shadow-2xl transition-transform duration-75 ease-out"
        style={{
          width: spreadWidthPx,
          height: spreadHeightPx,
          transform: `translate(${panOffset.x}px, ${panOffset.y}px) scale(${scale})`,
          transformOrigin: 'center center',
        }}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
      >
        {/* === LAYER 1: CLIPPED CONTENT === */}
        <div className="absolute inset-0 overflow-hidden bg-white">
            
            {/* Book Spine Effect (Center Gradient) */}
            <div 
              className="absolute top-0 bottom-0 left-1/2 w-16 -ml-8 z-0 pointer-events-none" 
              style={{
                background: 'linear-gradient(90deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0.05) 45%, rgba(0,0,0,0.1) 50%, rgba(0,0,0,0.05) 55%, rgba(0,0,0,0) 100%)'
              }}
            />

            {/* Center Spine Line (Dashed) */}
            <div className="absolute top-0 bottom-0 left-1/2 w-0 border-l border-dashed border-gray-300 z-10 pointer-events-none" />

            {/* Grid Overlay */}
            {showGrid && (
              <div 
                className="absolute inset-0 pointer-events-none z-0 opacity-20"
                style={{ 
                  backgroundImage: `linear-gradient(#000 1px, transparent 1px), linear-gradient(90deg, #000 1px, transparent 1px)`,
                  backgroundSize: `${DPI/2}px ${DPI/2}px` // 0.5 inch grid
                }} 
              />
            )}

            {/* Objects - CONTENT ONLY */}
            {currentSpread.objects
              .sort((a, b) => a.zIndex - b.zIndex)
              .map((obj) => (
                <DraggableObject
                  key={obj.id}
                  object={obj}
                  isSelected={state.selectedObjectId === obj.id}
                  scale={scale}
                  isPanningMode={isPanningMode} // Pass panning mode
                  onSelect={() => !isPanningMode && onSelectObject(obj.id)}
                  onUpdate={onUpdateObject}
                  onDelete={onDeleteObject}
                  onChangeOrder={onChangeOrder}
                  renderLayer="content"
                />
            ))}

            {/* Page Numbers */}
            <div className="absolute bottom-4 left-4 text-gray-400 text-2xl font-bold select-none pointer-events-none">
              {currentSpreadIndex * 2 + 1}
            </div>
            <div className="absolute bottom-4 right-4 text-gray-400 text-2xl font-bold select-none pointer-events-none">
              {currentSpreadIndex * 2 + 2}
            </div>
        </div>

        {/* === LAYER 2: UNCLIPPED OVERLAY === */}
        <div className="absolute inset-0 overflow-visible pointer-events-none">
            {/* Safe Area / Bleed Indicators */}
            {showBleed && (
              <div className="absolute inset-0 pointer-events-none border-2 border-red-400 z-0 opacity-50" style={{ margin: `${bleedPx}px` }}>
                <div className="absolute top-0 right-0 bg-red-400 text-white text-[20px] px-2 font-bold">Safe Area</div>
              </div>
            )}

            {/* Objects - CONTROLS ONLY */}
            {!isPanningMode && currentSpread.objects
              .sort((a, b) => a.zIndex - b.zIndex)
              .map((obj) => (
                <DraggableObject
                  key={`overlay-${obj.id}`}
                  object={obj}
                  isSelected={state.selectedObjectId === obj.id}
                  scale={scale}
                  isPanningMode={isPanningMode} // Pass panning mode
                  onSelect={() => onSelectObject(obj.id)}
                  onUpdate={onUpdateObject}
                  onDelete={onDeleteObject}
                  onChangeOrder={onChangeOrder}
                  renderLayer="overlay"
                />
            ))}
        </div>

      </div>
    </div>
  );
};